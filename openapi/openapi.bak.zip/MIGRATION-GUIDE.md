# OpenAPI Modularization Migration Guide

## Overview

This guide documents the migration from monolithic `openapi.yaml` (11,734 lines) to a modular structure (31 files).

## 🎯 Goals Achieved

1. ✅ Reduced main file size from 382.92 KB to 14.55 KB (96% reduction)
2. ✅ Separated 201 API endpoints into 14 domain-specific files
3. ✅ Organized 83 schemas into 16 logical groupings
4. ✅ Centralized 18 parameters into 1 reusable file
5. ✅ Enabled team collaboration without merge conflicts
6. ✅ Improved API discoverability and maintainability

## 📊 Before & After Comparison

| Metric | Before (Monolithic) | After (Modular) | Improvement |
|--------|---------------------|-----------------|-------------|
| Main file size | 382.92 KB | 14.55 KB | **96% smaller** |
| Total lines | 11,734 lines | ~330 lines (main) | **97% reduction** |
| Files | 1 file | 32 files | Better organization |
| Merge conflicts | Frequent | Rare | Team-friendly |
| Navigation | Difficult | Easy | By domain |
| Load time | Slow | Fast | Better performance |

## 🗂️ File Organization

### Paths (14 files)
```
openapi/paths/
├── auth.yaml                    # 4 endpoints   - Authentication
├── tenants-management.yaml      # 12 endpoints  - Tenant CRUD
├── tenants-users.yaml           # 18 endpoints  - User management
├── tenants-roles.yaml           # 14 endpoints  - Roles & permissions
├── tenants-products.yaml        # 35 endpoints  - Products (largest)
├── tenants-categories.yaml      # 8 endpoints   - Categories
├── tenants-suppliers.yaml       # 8 endpoints   - Suppliers
├── tenants-tags.yaml            # 8 endpoints   - Tags
├── tenants-customers.yaml       # 12 endpoints  - Customers
├── tenants-orders.yaml          # 15 endpoints  - Orders
├── tenants-variants.yaml        # 10 endpoints  - Variants
├── tenants-materials.yaml       # 12 endpoints  - Materials
├── tenants-recipes.yaml         # 10 endpoints  - Recipes/BOM
└── tenants-other.yaml           # 35 endpoints  - SKU, analytics, reports
```

### Schemas (16 files, 83 schemas total)
```
openapi/schemas/
├── auth.yaml           # 4 schemas   - Authentication models
├── tenant.yaml         # 5 schemas   - Tenant models
├── product.yaml        # 11 schemas  - Product models (largest)
├── category.yaml       # 3 schemas   - Category models
├── supplier.yaml       # 3 schemas   - Supplier models
├── tag.yaml            # 3 schemas   - Tag models
├── sku.yaml            # 3 schemas   - SKU models
├── role.yaml           # 4 schemas   - Role & Permission models
├── variant.yaml        # 8 schemas   - Variant models
├── stock.yaml          # 9 schemas   - Stock management models
├── customer.yaml       # 2 schemas   - Customer models
├── order.yaml          # 4 schemas   - Order models
├── analytics.yaml      # 6 schemas   - Analytics models
├── material.yaml       # 3 schemas   - Material models
├── recipe.yaml         # 6 schemas   - Recipe/BOM models
└── common.yaml         # 8 schemas   - Shared models (Error, Pagination, etc.)
```

### Parameters (1 file, 18 definitions)
```
openapi/parameters/
└── common.yaml         # All reusable parameters
    ├── Path parameters:  TenantId, ProductId, UserId, OrderId, CategoryId,
    │                     CustomerId, VariantId, SupplierId, TagId, RoleId
    └── Query parameters: Page, PerPage, Search, Status, DateFrom, DateTo,
                          SortBy, SortOrder
```

## 🔧 Migration Process

### Step 1: Backup Original File ✅
```bash
cp openapi.yaml openapi.yaml.backup
```

### Step 2: Create Folder Structure ✅
```bash
mkdir -p openapi/{paths,schemas,parameters,responses,examples}
```

### Step 3: Extract Parameters ✅
- Manually extracted lines 8144-8301
- Created `openapi/parameters/common.yaml`
- Fixed indentation (removed 4-space component prefix)

### Step 4: Extract Schemas ✅
- Created PowerShell script `extract-schemas.ps1`
- Defined 16 logical groupings
- Automatically extracted 83 schemas
- Corrected indentation to 2-space YAML standard

### Step 5: Extract Paths ✅
- Created PowerShell scripts `extract-paths-fast.ps1` and `extract-paths-fast2.ps1`
- Extracted 201 endpoints into 14 domain-specific files
- Fixed indentation (removed 2-space paths prefix)

### Step 6: Create Main Specification ✅
- Created `openapi-new.yaml` with all `$ref` imports
- Maintained original metadata (info, servers, security)
- Added all component references

### Step 7: Validation ⏳
```bash
# Validate structure (pending)
swagger-cli validate openapi-new.yaml

# Test with Swagger UI (pending)
swagger-ui openapi-new.yaml
```

### Step 8: Replace Original File ⏳
```bash
# After validation passes
mv openapi.yaml openapi.yaml.old
mv openapi-new.yaml openapi.yaml
```

## 🔄 Reference Syntax Guide

### Path References in Main File

OpenAPI uses JSON Pointer syntax with URL encoding:
- `/` becomes `~1`
- `{` and `}` remain as-is

**Examples:**

```yaml
# URL: /register
paths:
  /register:
    $ref: './openapi/paths/auth.yaml#/~1register'

# URL: /tenants/{tenantId}
paths:
  /tenants/{tenantId}:
    $ref: './openapi/paths/tenants-management.yaml#/~1tenants~1{tenantId}'

# URL: /tenants/{tenantId}/products/{productId}
paths:
  /tenants/{tenantId}/products/{productId}:
    $ref: './openapi/paths/tenants-products.yaml#/~1tenants~1{tenantId}~1products~1{productId}'
```

### Schema References

**In main file:**
```yaml
components:
  schemas:
    Product:
      $ref: './openapi/schemas/product.yaml#/Product'
```

**In path files:**
```yaml
# Reference schema from same directory level
schema:
  $ref: '../schemas/product.yaml#/Product'
```

**In schema files:**
```yaml
# Reference another schema in same file
properties:
  category:
    $ref: '#/Category'

# Reference schema from another file
properties:
  tenant:
    $ref: './tenant.yaml#/Tenant'
```

### Parameter References

**In path files:**
```yaml
parameters:
  - $ref: '../parameters/common.yaml#/TenantId'
  - $ref: '../parameters/common.yaml#/ProductId'
```

**In main file:**
```yaml
components:
  parameters:
    TenantId:
      $ref: './openapi/parameters/common.yaml#/TenantId'
```

## 📋 Validation Checklist

### Pre-Deployment Validation
- [ ] **Syntax validation**: `swagger-cli validate openapi-new.yaml`
- [ ] **Linting**: `spectral lint openapi-new.yaml`
- [ ] **Reference integrity**: Check all `$ref` paths resolve correctly
- [ ] **Schema validation**: Ensure all schemas match backend models
- [ ] **Example data**: Verify all examples are valid
- [ ] **Security definitions**: Confirm bearerAuth is applied correctly

### Visual Testing
- [ ] **Swagger UI**: Load and navigate all endpoints
- [ ] **Redoc**: Verify documentation renders correctly
- [ ] **Try It Out**: Test sample requests in Swagger UI

### Code Generation Testing
- [ ] **TypeScript client**: Generate and compile without errors
- [ ] **PHP stubs**: Generate Laravel stubs
- [ ] **Postman collection**: Generate and import

## 🐛 Common Issues & Fixes

### Issue 1: Invalid $ref Path
**Error**: `Can't resolve reference: './openapi/schemas/product.yaml#/Product'`

**Fix**: Check relative path from main file location
```yaml
# Correct (from project root)
$ref: './openapi/schemas/product.yaml#/Product'

# Wrong
$ref: 'openapi/schemas/product.yaml#/Product'  # Missing ./
$ref: '/openapi/schemas/product.yaml#/Product'  # Absolute path
```

### Issue 2: Indentation Errors
**Error**: `YAML parse error: bad indentation`

**Fix**: Use 2-space indentation consistently
```yaml
# Correct
Product:
  type: object
  properties:
    id:
      type: string

# Wrong (4 spaces)
Product:
    type: object
    properties:
        id:
            type: string
```

### Issue 3: Path Encoding
**Error**: Path reference not found

**Fix**: Use `~1` for forward slashes in JSON Pointer
```yaml
# Correct
paths:
  /tenants/{tenantId}/products:
    $ref: './openapi/paths/tenants-products.yaml#/~1tenants~1{tenantId}~1products'

# Wrong
paths:
  /tenants/{tenantId}/products:
    $ref: './openapi/paths/tenants-products.yaml#//tenants/{tenantId}/products'
```

### Issue 4: Circular References
**Error**: `Circular $ref reference detected`

**Fix**: Break circular dependency
```yaml
# Problematic
Product:
  properties:
    category:
      $ref: '#/Category'
Category:
  properties:
    products:
      type: array
      items:
        $ref: '#/Product'  # Circular!

# Fixed
Category:
  properties:
    products:
      type: array
      items:
        type: object  # Use inline object or ProductSummary
        properties:
          id:
            type: string
          name:
            type: string
```

## 🚀 Next Steps

### Immediate (This Week)
1. ✅ Complete extraction (DONE)
2. ⏳ Validate with `swagger-cli`
3. ⏳ Test with Swagger UI
4. ⏳ Replace original `openapi.yaml`
5. ⏳ Update `.gitignore` (ignore `openapi.yaml.backup`)

### Short-term (Next Sprint)
6. ⏳ Update CI/CD to validate modular spec
7. ⏳ Generate TypeScript client for frontend
8. ⏳ Update developer onboarding docs
9. ⏳ Train team on new structure

### Long-term (Ongoing)
10. ⏳ Add response examples to all endpoints
11. ⏳ Create shared response templates (`responses/` folder)
12. ⏳ Add integration tests for spec compliance
13. ⏳ Implement Image & Location enhancement (Days 2-15)

## 🎓 Learning Resources

### OpenAPI Specification
- [OpenAPI 3.0 Spec](https://swagger.io/specification/)
- [Using $ref](https://swagger.io/docs/specification/using-ref/)
- [Components & Reusability](https://swagger.io/docs/specification/components/)

### Tools
- [Swagger Editor](https://editor.swagger.io/) - Online editor with validation
- [Swagger UI](https://swagger.io/tools/swagger-ui/) - Interactive documentation
- [Redoc](https://redocly.com/docs/) - Beautiful API documentation
- [Spectral](https://stoplight.io/open-source/spectral) - OpenAPI linter
- [OpenAPI Generator](https://openapi-generator.tech/) - Code generation

### Best Practices
- [OpenAPI Style Guide](https://apistylebook.com/design/topics/)
- [REST API Design](https://restfulapi.net/)
- [API-First Development](https://swagger.io/resources/articles/adopting-an-api-first-approach/)

## 📞 Support

If you encounter issues during migration:
1. Check this guide's **Common Issues** section
2. Validate with `swagger-cli validate openapi-new.yaml`
3. Test specific path files individually
4. Review extraction scripts for debugging

For API structure questions, refer to:
- **README**: `openapi/README.md`
- **Repo Rules**: `.zencoder/rules/repo.md`
- **Implementation Plan**: `IMAGE-LOCATION-ENHANCEMENT-SUMMARY.md`

---

**Migration Date**: January 2025  
**Status**: ✅ Extraction Complete, ⏳ Validation Pending  
**Version**: OpenAPI 3.0.3  
**Project**: Canvastack POSMID