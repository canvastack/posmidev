# Panduan Maintenance Struktur OpenAPI Modular

## 📋 Ringkasan

Struktur OpenAPI telah direfaktor dari satu file monolithic (`openapi.yaml` - 12,098 baris) menjadi struktur modular dengan:
- **1 file utama**: `openapi-new.yaml` (477 baris)
- **23 file paths**: `openapi/paths/` (termasuk BOM Engine)
- **16 file schemas**: `openapi/schemas/`
- **1 file parameters**: `openapi/parameters/common.yaml`

## 🏗️ Struktur Direktori

```
openapi/
├── openapi-new.yaml              # File utama dengan semua referensi
├── README.md                     # Dokumentasi utama
├── MAINTENANCE-GUIDE.md         # Panduan ini
├── MIGRATION-GUIDE.md           # Panduan migrasi dari struktur lama
├── parameters/
│   └── common.yaml              # Parameter umum (TenantId, pagination, dll)
├── paths/                       # Endpoint definitions
│   ├── auth.yaml               # Authentication endpoints
│   ├── tenants-products.yaml   # Product management endpoints
│   ├── tenants-materials.yaml  # BOM Engine - Materials
│   ├── tenants-recipes.yaml    # BOM Engine - Recipes
│   ├── tenants-bom-*.yaml      # BOM Engine lainnya
│   └── tenants-*.yaml          # Endpoint lainnya
├── schemas/                     # Schema definitions
│   ├── auth.yaml               # Authentication schemas
│   ├── product.yaml            # Product schemas
│   ├── material.yaml           # BOM Material schemas
│   ├── recipe.yaml             # BOM Recipe schemas
│   └── *.yaml                  # Schema lainnya
└── _backup_YYYYMMDD_HHMMSS/    # Backup otomatis
```

## 🔧 Cara Kerja Referensi

### 1. Referensi Internal (dalam file paths)
```yaml
# Dalam file paths, gunakan referensi internal
$ref: '#/components/schemas/Product'
$ref: '#/components/parameters/TenantId'
```

### 2. Referensi Eksternal (dari file utama)
```yaml
# Dalam openapi-new.yaml, gunakan referensi eksternal
$ref: './openapi/paths/auth.yaml#/~1register'
$ref: './openapi/schemas/product.yaml#/Product'
```

### 3. JSON Pointer Encoding
- `/` dalam path di-encode sebagai `~1`
- `~` dalam path di-encode sebagai `~0`
- Contoh: `/tenants/{tenantId}/products` → `#/~1tenants~1{tenantId}~1products`

## 📝 Aturan Penamaan File

### Paths Files
- **Pola**: `tenants-{modul}.yaml`
- **Contoh**:
  - `tenants-products.yaml` - Product management
  - `tenants-materials.yaml` - BOM Materials
  - `tenants-analytics.yaml` - Analytics endpoints

### Schema Files
- **Pola**: `{domain}.yaml`
- **Contoh**:
  - `product.yaml` - Product schemas
  - `material.yaml` - Material schemas
  - `auth.yaml` - Authentication schemas

## 🚀 Menambah Endpoint Baru

### 1. Menambah ke File Paths yang Ada
```bash
# Edit file paths yang relevan
code openapi/paths/tenants-products.yaml
```

### 2. Membuat File Paths Baru
```bash
# 1. Buat file baru dengan template
cp openapi/paths/tenants-products.yaml openapi/paths/tenants-newmodule.yaml

# 2. Edit file baru
code openapi/paths/tenants-newmodule.yaml

# 3. Tambahkan referensi di openapi-new.yaml
code openapi-new.yaml
# Tambahkan baris seperti:
# /tenants/{tenantId}/newmodule:
#   $ref: './openapi/paths/tenants-newmodule.yaml#/~1tenants~1{tenantId}~1newmodule'
```

### 3. Menambah Schema Baru
```bash
# 1. Buat file schema baru
touch openapi/schemas/newentity.yaml

# 2. Edit file schema
code openapi/schemas/newentity.yaml

# 3. Tambahkan referensi di openapi-new.yaml components.schemas
```

## 🔍 Validasi dan Testing

### Validasi Syntax
```bash
# Validasi file utama
npx swagger-parser validate openapi-new.yaml

# Atau gunakan online validator:
# https://editor.swagger.io/
```

### Testing Manual
1. **Load di Swagger UI**:
   ```bash
   # Install swagger-ui-watcher
   npm install -g swagger-ui-watcher

   # Jalankan
   npx swagger-ui-watcher openapi-new.yaml
   ```

2. **Test Endpoint**:
   - Buka Swagger UI
   - Test endpoint `/register` dan `/login`
   - Test endpoint produk dengan tenant ID
   - Test endpoint BOM Engine

### Automated Testing
```bash
# Install testing tools
npm install -g dredd

# Test dengan server lokal
dredd openapi-new.yaml http://localhost:9000/api/v1
```

## 🛠️ Troubleshooting

### Masalah Referensi Tidak Ditemukan
1. **Periksa path file**: Pastikan path relatif benar
2. **Periksa JSON pointer**: Pastikan encoding `~1` untuk `/`
3. **Validasi syntax**: Pastikan tidak ada karakter BOM atau error YAML

### Masalah Schema Tidak Valid
1. **Periksa format schema**: Pastikan mengikuti OpenAPI 3.0.3
2. **Periksa referensi**: Pastikan semua `$ref` mengarah ke schema yang ada
3. **Validasi contoh**: Pastikan `example` values valid

### Masalah Performance
- Struktur modular seharusnya lebih cepat dimuat
- Jika lambat, periksa ukuran file individual
- Consider splitting file besar (>1000 baris)

## 📋 Best Practices

### 1. Development Workflow
```bash
# 1. Buat branch baru
git checkout -b feature/new-endpoint

# 2. Edit file yang relevan
code openapi/paths/tenants-relevant.yaml

# 3. Validasi perubahan
npx swagger-parser validate openapi-new.yaml

# 4. Test dengan Swagger UI
npx swagger-ui-watcher openapi-new.yaml

# 5. Commit dengan backup
git add .
git commit -m "feat: add new endpoint with backup"
```

### 2. Backup Strategy
- Backup otomatis dibuat sebelum setiap perubahan besar
- Backup manual sebelum refactoring besar
- Simpan backup minimal 30 hari

### 3. Code Review Checklist
- [ ] Semua referensi `$ref` menggunakan format yang benar
- [ ] Tidak ada duplikasi konten
- [ ] Tidak ada karakter BOM
- [ ] Syntax YAML valid
- [ ] Mengikuti pola penamaan
- [ ] Dokumentasi updated jika diperlukan

## 🔄 Maintenance Schedule

### Daily
- Validasi syntax file utama
- Test endpoint kritis

### Weekly
- Review struktur file
- Update dokumentasi jika diperlukan
- Backup manual jika ada perubahan besar

### Monthly
- Review performa loading
- Audit konsistensi referensi
- Update dependencies tools

## 📞 Kontak dan Support

Jika ada pertanyaan atau masalah:
1. Periksa dokumentasi di folder ini
2. Lihat contoh di file existing
3. Buat issue di repository
4. Hubungi tim backend development

---

**Dibuat**: 11 Oktober 2025
**Pembuat**: Kilo Code (AI Assistant)
**Versi**: 1.0.0