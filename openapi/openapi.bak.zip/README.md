# OpenAPI Modular Structure

This directory contains the modularized OpenAPI specification for Canvastack POSMID API.

## 📁 Structure

```
openapi/
├── README.md                    # Dokumentasi utama
├── MAINTENANCE-GUIDE.md         # Panduan maintenance lengkap
├── MIGRATION-GUIDE.md           # Panduan migrasi dari struktur lama
├── parameters/                  # Parameter umum (1 file)
│   └── common.yaml             # TenantId, ProductId, UserId, Page, PerPage, Search, etc.
├── paths/                       # API endpoint definitions (23 files)
│   ├── auth.yaml               # Authentication endpoints (/register, /login, /logout, /user)
│   ├── tenants-management.yaml # Tenant CRUD & settings
│   ├── tenants-users.yaml      # User management within tenants
│   ├── tenants-roles.yaml      # Roles & permissions management
│   ├── tenants-products.yaml   # Product CRUD, images, tags, barcode, export/import
│   ├── tenants-categories.yaml # Category management
│   ├── tenants-suppliers.yaml  # Supplier management
│   ├── tenants-tags.yaml       # Tag management
│   ├── tenants-customers.yaml  # Customer CRUD & export/import
│   ├── tenants-orders.yaml     # Order management
│   ├── tenants-variants.yaml   # Product variants
│   ├── tenants-materials.yaml  # Material/ingredient management (BOM Engine)
│   ├── tenants-recipes.yaml    # Recipe/BOM management (BOM Engine)
│   ├── tenants-analytics.yaml  # Analytics endpoints
│   ├── tenants-sku.yaml        # SKU generation
│   ├── tenants-stock.yaml      # Stock management
│   ├── tenants-bom-*.yaml      # BOM Engine lainnya (6 files)
│   └── tenants-other.yaml      # Utility endpoints
├── schemas/                     # Data model definitions (16 files)
│   ├── auth.yaml               # RegisterRequest, LoginRequest, AuthResponse, User
│   ├── tenant.yaml             # Tenant, TenantCreateRequest, TenantUpdateRequest, TenantSettings
│   ├── product.yaml            # Product, ProductCreateRequest, ProductImage, ProductTag, etc.
│   ├── category.yaml           # Category schemas
│   ├── supplier.yaml           # Supplier schemas
│   ├── tag.yaml                # Tag schemas
│   ├── sku.yaml                # SKU generation schemas
│   ├── role.yaml               # Role & Permission schemas
│   ├── variant.yaml            # Variant, VariantAttribute, VariantPricing, VariantStock
│   ├── stock.yaml              # StockAdjustment, StockTransaction, StockAlert, Inventory
│   ├── customer.yaml           # Customer schemas
│   ├── order.yaml              # Order, OrderItem schemas
│   ├── analytics.yaml          # SalesAnalytics, ProductAnalytics, DashboardMetrics
│   ├── material.yaml           # Material/ingredient schemas (BOM Engine)
│   ├── recipe.yaml             # Recipe, RecipeMaterial, BOMCalculation (BOM Engine)
│   └── common.yaml             # Pagination, ErrorResponse, MessageResponse, etc.
└── _backup_YYYYMMDD_HHMMSS/    # Backup otomatis dengan timestamp
    ├── paths/                  # Backup semua file paths
    └── schemas/                # Backup semua file schemas
```

## 🎯 Benefits

### Before (Monolithic)
- **Size**: 382.92 KB, 11,734 lines
- **Structure**: Single file with all definitions
- **Problems**: 
  - Hard to navigate
  - Merge conflicts frequent
  - Difficult to maintain
  - Slow editor performance

### After (Modular)
- **Main file**: 14.55 KB, ~330 lines
- **Modules**: 31 separate files organized by domain
- **Benefits**:
  - ✅ Easy navigation by feature
  - ✅ Minimal merge conflicts (teams work on separate files)
  - ✅ Better code review (smaller, focused diffs)
  - ✅ Faster editor loading
  - ✅ Clear ownership by domain
  - ✅ Supports API-First development workflow

## 🚀 Usage

### Main Entry Point
The main specification file is **`openapi-new.yaml`** in the project root. It imports all modules using `$ref`.

### Viewing the API
```bash
# Using Swagger UI (if installed)
swagger-ui openapi-new.yaml

# Using Redoc (if installed)
redoc-cli serve openapi-new.yaml

# Using online viewer
# Upload openapi-new.yaml to https://editor.swagger.io
```

### Validation
```bash
# Using swagger-cli
swagger-cli validate openapi-new.yaml

# Using openapi-generator-cli
openapi-generator-cli validate -i openapi-new.yaml

# Using spectral
spectral lint openapi-new.yaml
```

### Code Generation
```bash
# Generate TypeScript client
openapi-generator-cli generate -i openapi-new.yaml -g typescript-axios -o frontend/src/api

# Generate PHP server stubs
openapi-generator-cli generate -i openapi-new.yaml -g php-laravel -o backend-stubs
```

## 📝 Editing Guidelines

### Adding a New Endpoint

1. **Determine the module** (e.g., products, customers, orders)
2. **Edit the appropriate path file** (e.g., `paths/tenants-products.yaml`)
3. **Add path definition** with proper indentation:
```yaml
/tenants/{tenantId}/products/{productId}/images:
  post:
    tags: [Products]
    summary: Upload product image
    operationId: uploadProductImage
    parameters:
      - $ref: '../parameters/common.yaml#/TenantId'
      - $ref: '../parameters/common.yaml#/ProductId'
    requestBody:
      required: true
      content:
        multipart/form-data:
          schema:
            type: object
            properties:
              image:
                type: string
                format: binary
    responses:
      '201':
        description: Image uploaded successfully
        content:
          application/json:
            schema:
              $ref: '../schemas/product.yaml#/ProductImage'
```
4. **Reference from main file** (`openapi-new.yaml`):
```yaml
paths:
  /tenants/{tenantId}/products/{productId}/images:
    $ref: './openapi/paths/tenants-products.yaml#/~1tenants~1{tenantId}~1products~1{productId}~1images'
```

### Adding a New Schema

1. **Edit the appropriate schema file** (e.g., `schemas/product.yaml`)
2. **Add schema definition**:
```yaml
ProductImage:
  type: object
  properties:
    id:
      type: string
      format: uuid
    product_id:
      type: string
      format: uuid
    url:
      type: string
      format: uri
    is_primary:
      type: boolean
    created_at:
      type: string
      format: date-time
```
3. **Reference from main file** (`openapi-new.yaml`):
```yaml
components:
  schemas:
    ProductImage:
      $ref: './openapi/schemas/product.yaml#/ProductImage'
```

### Adding a New Parameter

1. **Edit** `parameters/common.yaml`
2. **Add parameter definition**:
```yaml
ImageId:
  name: imageId
  in: path
  required: true
  schema:
    type: string
    format: uuid
  description: The unique identifier for an image
```
3. **Reference from paths**:
```yaml
parameters:
  - $ref: '../parameters/common.yaml#/ImageId'
```

## 🔄 Migration Status

### ✅ Completed
- [x] Folder structure created
- [x] Parameters extracted (1 file with 18 definitions)
- [x] Schemas extracted (16 files with 83 schemas)
- [x] Paths extracted (23 files with 201+ endpoints including BOM Engine)
- [x] Main specification file created (`openapi-new.yaml`)
- [x] Original file backed up (`openapi.yaml.backup`)
- [x] **Critical fixes applied** (BOM character, duplicate content, syntax validation)
- [x] **Maintenance guide created** (`MAINTENANCE-GUIDE.md`)

### ⏳ Pending
- [ ] Validate with `swagger-cli validate`
- [ ] Test with Swagger UI
- [ ] Replace `openapi.yaml` with `openapi-new.yaml`
- [ ] Update CI/CD pipelines to use new structure
- [ ] Update developer documentation

### 🎯 Next Steps (Image & Location Enhancement - Days 2-15)
When implementing the Image & Location features, add new endpoints/schemas to:
- **Tenant logo**: `paths/tenants-management.yaml`, `schemas/tenant.yaml`
- **User photo**: `paths/tenants-users.yaml`, `schemas/auth.yaml`
- **Customer photo**: `paths/tenants-customers.yaml`, `schemas/customer.yaml`
- **Location fields**: Update respective schema files with latitude/longitude fields

## 📚 Reference Syntax

### Path Reference in main file
```yaml
# URL: /tenants/{tenantId}/products
# Reference: ./openapi/paths/tenants-products.yaml#/~1tenants~1{tenantId}~1products
# Note: ~1 = escaped forward slash (/)
```

### Schema Reference
```yaml
# Internal reference (within same file)
$ref: '#/components/schemas/Product'

# External reference (from another file)
$ref: './openapi/schemas/product.yaml#/Product'
```

### Parameter Reference
```yaml
# From paths file
$ref: '../parameters/common.yaml#/TenantId'

# From main file
$ref: './openapi/parameters/common.yaml#/TenantId'
```

## 🔧 Tools & Scripts

### Extraction Scripts
- `extract-schemas.ps1` - Automated schema extraction from monolithic file
- `extract-paths-fast.ps1` - Fast path extraction (part 1)
- `extract-paths-fast2.ps1` - Fast path extraction (part 2)

### Running Scripts
```powershell
# Re-extract schemas (if needed)
powershell -File openapi/extract-schemas.ps1

# Re-extract paths (if needed)
powershell -File openapi/extract-paths-fast.ps1
powershell -File openapi/extract-paths-fast2.ps1
```

## 📖 Resources

- [OpenAPI 3.0 Specification](https://swagger.io/specification/)
- [OpenAPI $ref Guide](https://swagger.io/docs/specification/using-ref/)
- [Swagger Editor](https://editor.swagger.io/)
- [Redoc Documentation](https://redocly.com/docs/)
- [OpenAPI Generator](https://openapi-generator.tech/)
- **[Maintenance Guide](./MAINTENANCE-GUIDE.md)** - Panduan lengkap untuk maintenance struktur modular

## 🤝 Contributing

When adding new endpoints or schemas:
1. Follow the existing structure and naming conventions
2. Use `$ref` for reusable components
3. Group related endpoints in the same path file
4. Keep schemas focused and single-purpose
5. Document all fields with descriptions and examples
6. Update this README if adding new modules

## 📞 Support

For questions about the API structure, refer to:
- **Project Documentation**: `/docs`
- **Architecture Guide**: `/.zencoder/rules/repo.md`
- **API Roadmap**: `/IMAGE-LOCATION-ENHANCEMENT-SUMMARY.md`